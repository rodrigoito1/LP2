﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PCalc
{
    public partial class Form1 : Form
    {
     double numero1;
     double numero2;
     double resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtRes.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?","Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes) 
                {
                Close();

                }
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            
            if (!Double.TryParse(txtNum1.Text, out numero1))
            {

                MessageBox.Show("Número 1 inválido!");
                txtNum1.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {

                MessageBox.Show("Número 2 inválido!");
                txtNum1.Focus();
            }
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtRes.Text = resultado.ToString();

        }

        private void btnSub_Click(object sender, EventArgs e)
        {

            resultado = numero1 - numero2; 
            txtRes.Text = resultado.ToString();

        }

        private void btnMult_Click(object sender, EventArgs e)
        {

            resultado = numero1 * numero2;
            txtRes.Text = resultado.ToString();

        }

        private void btnDiv_Click(object sender, EventArgs e)
        {

            if (numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();

            }
            else
            {
                resultado = numero1 / numero2;
                txtRes.Text = resultado.ToString();
            }
        }
    }
}

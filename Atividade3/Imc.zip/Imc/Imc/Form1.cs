﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imc
{
    
    public partial class Form1 : Form
    {
        double altura;
        double peso;
        double imc;
        string classificacao;
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (altura*altura);
            imc = Math.Round(imc, 1);
            txtImc.Text = imc.ToString();

            if (imc < 18.5)
            {
                classificacao = "Magreza";
            }
            else if (imc < 25)
            {
                classificacao = "Normal";

            }
            else if (imc < 30)
            {
                classificacao = "Sobrepeso";
            }
            else if (imc < 40)
            {
                classificacao = "Obesidade";
            }
            else if (imc >= 40)
            {
                classificacao = "Obesidade grave";
            }
            txtClas.Text = classificacao;
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtPeso.Text, out peso)) || (peso <= 0))
            {

                MessageBox.Show("Peso inválido!");
                txtPeso.Focus();
            }
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtAltura.Text, out altura)) || (altura <= 0))
            {

                MessageBox.Show("Altura inválido!");
                txtAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
            txtClas.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();

            }
            Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double valorRaio;
            if (!double.TryParse(txtRaio.Text, out valorRaio))
            {
                MessageBox.Show("Raio inválido");
            }
        }
        private void txtAltura_Validated(object sender, EventArgs e)
        {
            double valorRaio;
            if (!double.TryParse(txtAltura.Text, out valorRaio))
            {
                MessageBox.Show("Altura inválido");
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double valorAltura, valorRaio;

            if ((!double.TryParse(txtRaio.Text, out valorRaio ))
                || (!double.TryParse(txtAltura.Text, out valorAltura)))
            {
                MessageBox.Show("Valores inválidos!");
                txtRaio.Focus();
            }
            else
            {
                double volume;
                volume = Math.PI * Math.Pow(valorRaio, 2) * valorAltura;

                txtVolume.Text = volume.ToString("N2");
            }
                }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}